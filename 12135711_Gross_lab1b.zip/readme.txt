1.
Implemented:
T1: Fully Implemented. Looks correct to me.
T2: Fully Implemented. Should work as intended.
T3: Fully Implemented. Should work as intended.
T4: Fully Implemented. Should work as intended.
T5a: Fully Implemented. The program will start in default mode with no shading active. w,e,r,t will switch to the specified shader models. Press d to return to the default no light.
Console will tell you whats currently active.
T5b: Fully Implemented. press L to toggle Light interaction on and off. Translation and rotation should work as intended. Testet it a bunch and to me it looks correct.


2.
Tested Environments:
OS: Windows 10
Browser: Google Chrome Version 111.0.5563.147 (Official Build) (64-Bit)
Development Environment: Visual Studio Code
Webserver: Visual Studio addon: "Preview on Web Server" by Yuichi Nukiyama

3.
Thanks a lot for the help on discord :)